
public class If {

	public static void main(String[] args) {
		int x=10;
		if(x%2==0)
			System.out.println(x+" is even no");
		else 
			System.out.println(x+" is odd no");
		
		
		System.out.println(x%4);
		System.out.println(x%5);
		System.out.println(x%6);
		System.out.println(x%10);
		System.out.println(x%11);
		System.out.println(x%12);
		
		System.out.println();
		System.out.println(x/5);
		System.out.println(x/6);
		System.out.println(x/7);
		System.out.println(x/8);
		System.out.println(x/9);
		System.out.println(x/10);
		System.out.println(x/11);
		System.out.println(x/11.0);
		
		
		
		
		
	}
}
