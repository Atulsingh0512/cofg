package corejava;

public class BoyMain {

	public static void main(String[] args) {

		Boy boy=new Boy(10001, "kamal partap", 20, WeekDays.Thursday);
		
		System.out.println(boy);
	}
}
