package com.coforge.model;

public interface Employee {

	public void employeeInfo();

}
