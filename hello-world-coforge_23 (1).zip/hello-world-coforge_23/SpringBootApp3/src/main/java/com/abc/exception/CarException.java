package com.abc.exception;

public class CarException extends Exception {
	public CarException(String s) {
		super(s);
	}

}
