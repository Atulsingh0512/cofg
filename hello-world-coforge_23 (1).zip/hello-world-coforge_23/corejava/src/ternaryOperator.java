
public class ternaryOperator {

	public static void main(String[] args) {

		int marks = 67;
		String res = (marks >= 35 ? "pass" : "fail");
		System.out.println(res);
		
		
		

	}
}
