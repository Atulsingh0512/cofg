function hello(){
    alert('hello world')
   }

   function fullname(fname,lname){
    return "your name is "+(fname+'  '+lname)
   }

