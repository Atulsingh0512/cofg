package com.example.aop;

import org.springframework.stereotype.Component;

@Component
public class Program1 {

	public void display() {
		System.out.println("display called ");
	}
	
}
