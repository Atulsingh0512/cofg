package com.example.model;

import lombok.Data;

@Data
public class Product {

	private int prdId;
	private  String prdName;
	private float prdCost;
	
	
}
