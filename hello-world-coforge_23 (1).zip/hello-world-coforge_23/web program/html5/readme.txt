id is unique for any of the tag
id is used by the differrent functions in javascript

 like document.getElementById

    getElementById()
    getElementsByName()

 and  by InnerHtml


InnerHtml

    <div>
   hello ----------------- inner html
    </div>




