import static java.lang.Math.PI;
import static java.lang.System.out;
import static java.lang.Math.*;

public class staticPrg2 {

	public static void main(String[] args) {
	//	System.out.println(Math.PI);
		System.out.println(PI);
		System.out.println(E);
		System.out.println(sin(PI/2));
		
		out.println("hello");
		
	}
}
