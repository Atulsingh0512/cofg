
public class Addition {
	public static void main(String[] args) {

		 java.util.Scanner sc=new java.util.Scanner(System.in);
		 int x,y,z;
		 
		 System.out.println("Enter first no");
		 x=sc.nextInt();
		 
		 System.out.println("Enter second no");
		 y=sc.nextInt();
		 
		 z=x+y;
		 System.out.printf("\nSum of %d and %d is %d",x,y,z);
		 
		
	}

}
