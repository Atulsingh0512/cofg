package com.example.model;

public class User {

	private int id;
	private  String name;
	
	private float salary;
}
