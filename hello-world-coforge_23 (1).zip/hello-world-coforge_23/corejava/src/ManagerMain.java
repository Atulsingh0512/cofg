
public class ManagerMain {

	public static void main(String[] args) {
		Manager manager = new BankManager
				(10001, "suresndra kumar", 50000, 0.05f, 0.1f);

		manager.managerInfo();
	}

}
