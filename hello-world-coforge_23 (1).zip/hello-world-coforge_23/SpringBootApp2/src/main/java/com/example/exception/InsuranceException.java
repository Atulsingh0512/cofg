package com.example.exception;

public class InsuranceException extends Exception {
	public InsuranceException(String s) {
		super(s);
	}
}
