


   java web app----> only with java 

   c++ appl === c++ appl

   web service ---- java-- connect java,c++ ,node

   book ticket --  payment -- webservice--


        web service soap (simple object access protocol ) -- xml data 
        
        REST  -- better than soap -- json , xml, html
       

       json -- javascript object notation

       json better than xml 

       json -- javascript, nodejs, expressjs, angular, react, nest


     CRUD --
                    C -- create 
                    R -- retrieve
                    U -- update
                    D -- delete    
     express js rest application 

            json -- data -- methods -- 
                                     sql 
                      post -- C --- create  
                      get  -- R --- select 
                      put  -- U --- update
                      delete--D --- delete
         

     react, angulat


     expressjs, spring boot rest ----- >json --  consumed by react, amgular(UI, front end)
        api(json data )                      -->  ui 

        api developer                               ui -- react, angular 
            expressjs, spring boot rest      
