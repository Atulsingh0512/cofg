public class NegativeAmount  extends Exception{
}
