
public class Test1 {

	public static void main(String[] args) {
		int x=10;
		int y=20;
		int z=x+y;
		// ctrl+alt+down arrow -- duplicate 
		// alt+ up arrow, down arrow -- line movement
		//ctrl+d -- delete current line 
		
		System.out.println("calculation program ");
		System.out.println("no1 is "+x);
		System.out.println("no2 is "+y);
		System.out.println("sum is "+z);
	}
}
