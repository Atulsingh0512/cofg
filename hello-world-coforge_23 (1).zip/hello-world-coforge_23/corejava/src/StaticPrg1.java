
public class StaticPrg1 {

	public static void main(String[] args) {
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println(Math.sin(Math.PI/2));
		
		System.out.println(Math.pow(2, 4));
		
		System.out.println();
	}
}
