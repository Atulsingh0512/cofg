package com.abc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainApp1 {

	public static void main(String[] args) {
		SpringApplication.run(MainApp1.class, args);
	}
}
