
public class Diff_No {

	public static void main(String[] args) {
		int x=766767;
		int y=0b1011110;// prefix 0b allow to take binary digit
		int z=0xabcd198;// prefix 0x allow to take hex decimal  digit
		                // hex decimal 0 -9 and a -f     
		
		int a=012345; // prefix 0 make it octal no(0 -7 )
		
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		System.out.println(a);
	}
}
