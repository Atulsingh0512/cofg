var a=100
var b=200

 fun1=()=>{
    console.log('my function');
};

 sum=(x,y)=>{
  return x+y;
};

module.exports={
    a:a,
    b:b,
    myfunction:fun1,
     addition:sum
};