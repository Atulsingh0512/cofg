package com.coforge.model;

public class Hello {

	public void sayHello() {
		System.out.println("hello to spring");
	}
}
