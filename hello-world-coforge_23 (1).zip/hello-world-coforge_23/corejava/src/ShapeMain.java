
public class ShapeMain {

	public static void main(String[] args) {
		
		Shape s1;
		
		s1=new Circle1();
		s1.area();
		
		s1=new Rectangle(12, 30);
		s1.area();
	}
}
