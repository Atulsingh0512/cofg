console.log('welcome to nodejs');
setTimeout(()=>{
    console.log('hello world')
},3000)


