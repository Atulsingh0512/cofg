
public class LowBalanceException  extends Exception{
}
