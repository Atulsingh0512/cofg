
public class InsufficientFunds  extends Exception{

}
