package corejava;

public interface WeekDays {
  int Monday=1;
  int Tuesday=2;
  int Wednesday=3;
  int Thursday=4;
  int Friday=5;
  int Saturday=6;
  int Sunday=7;
}
