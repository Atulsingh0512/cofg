var p=require('./no');
console.log(p.a)
console.log(p.b)

p.myfunction()
console.log(p.addition(1,2));
console.log(p.addition(p.a,p.b));