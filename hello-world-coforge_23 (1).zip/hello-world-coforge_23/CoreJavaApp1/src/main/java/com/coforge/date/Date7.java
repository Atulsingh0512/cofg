package com.coforge.date;

import java.util.Date;

public class Date7 {

	public static void main(String[] args) {
		
		Date date=new Date();
		System.out.println(date);
		
		date=new Date(1);
		System.out.println(date);
	}
}
