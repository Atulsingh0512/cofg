
public class Shape {
 void area() {
	 System.out.println("area of shape");
 }
}
