var date=new Date()
alert(date)
alert(date.getHours()+":"+date.getMinutes()+":"+date.getSeconds())
console.log(date.toDateString())
console.log(date.toLocaleDateString())

console.log(date.toTimeString())
console.log(date.toLocaleTimeString())

