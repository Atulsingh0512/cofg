
public class EmployeeMain {

	public static void main(String[] args) {
		
	  //System.out.println("Country is "+Employee.country);	
	   //Employee employee=new Employee();
	   //employee.employeeInfo();
		
		//new Employee().employeeInfo();// no reference variable
	   
//		Employee.employeeInfo1(new Employee());
	
		Employee emp1=new Employee();
		Employee.employeeInfo1(emp1);
	}
}
