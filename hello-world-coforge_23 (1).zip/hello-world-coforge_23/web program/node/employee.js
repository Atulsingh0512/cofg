const employee=[
    {"id":10001,"name":"suresh kumar","salary":35000},
    {"id":10002,"name":"avant kumar","salary":12000},
    {"id":10003,"name":"salman akhtar","salary":90000},
    {"id":100010,"name":"kashif hussain","salary":55000},
    {"id":10004,"name":"raman sinha","salary":15000},
    {"id":10007,"name":"ishaan jaiswa","salary":45000}
 ];

 module.exports=employee